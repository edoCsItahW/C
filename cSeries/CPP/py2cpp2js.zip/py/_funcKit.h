// Copyright (c) 2024. All rights reserved.
// This source code is licensed under the CC BY-NC-SA
// (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
// This software is protected by copyright law. Reproduction, distribution, or use for commercial
// purposes is prohibited without the author's permission. If you have any questions or require
// permission, please contact the author: 2207150234@st.sziit.edu.cn

/*****************************************************
 * @File name: bridging
 * @Author: edocsitahw
 * @Version: 1.1
 * @Date: 2024/08/10 下午5:46
 * @Commend:
 *******************************************************/

#ifndef BRIDGING__FUNCKIT_H
#define BRIDGING__FUNCKIT_H
#pragma once

#include <any>
#include <napi.h>
#include <vector>
#include <tuple>
#include <utility>
#include "global.h"


//template<typename F, typename... Args>
//auto debug(
//	F func,
//	Napi::Env env,
//	std::source_location loc = std::source_location::current()
//) {
//	return [func, env, loc](Args&&... args) {
//		try {
//			return func(std::forward<Args>(args)...);
//
//		}
//		catch (const std::exception& e) {
//			std::string info = "Traceback (most recent call last):\n"
//							   "\tFile: " + std::string(loc.file_name())
//							 + ", line: " + std::to_string(loc.line())
//							 + ", in <" + std::string(loc.function_name()) + ">";
//
//			Napi::Error::New(env, info + "\n" + e.what()).ThrowAsJavaScriptException();
//
//		}
//	};
//}
//template<typename F>
//class Debug {
//	private:
//		F func;
//		Napi::Env env;
//		std::source_location loc;
//
//	public:
//		Debug(F f, Napi::Env e, std::source_location l = std::source_location::current()) : func(f), env(e), loc(l) {
//
//		}
//
//		template<typename... Args>
//		auto operator()(Args&&... args) {
//			try {
//				return func(std::forward<Args>(args)...);
//			}
//			catch (const std::exception& e) {
//				std::string info = "Traceback (most recent call last):\n"
//								   "\tFile: " + std::string(loc.file_name())
//								 + ", line: " + std::to_string(loc.line())
//								 + ", in <" + std::string(loc.function_name()) + ">";
//
//				Napi::Error::New(env, info + "\n" + e.what()).ThrowAsJavaScriptException();
//			}
//		}
//};


template<class T, class U = py::object>
/**
	 * @tparam T 子类模板参数
	 * @tparam U 父类模板参数
	 * @brief 检测T是否是U的子类
 */
concept isChildOf = std::is_base_of<U, T>::value;


template<typename F, typename T>
/**
	 * @brief 转换python对象为cpp对象的函数模板
	 * @tparam F 转换函数类型,必须满足Py2CppFn concept.
	 * @tparam T 一个辅助检查类型,用于检查转换函数的返回类型是否与T一致.
 */
concept Py2CppFn = requires(F fn, py::object obj) { { fn(obj) } -> std::same_as<T>; };


template<typename F, typename T>
/**
	 * @brief 转换cpp对象为js对象的函数模板
	 * @tparam F 转换函数类型,必须满足Cpp2JsFn concept.
	 * @tparam T 一个辅助检查类型,用于检查转换函数作用于该类型后的返回类型是否与node::Value一致.
 */
concept Cpp2JsFn = requires(F fn, T cpp) { { fn(cpp) } -> std::same_as<Napi::Value>; };


using AttrPair = std::pair<py::object, std::string>;


AttrPair getPyAttr(const char* type, const char *key);


AttrPair getPyAttr(const char* type, const char *key, Napi::Env env);


py::object toPyAttr(const Napi::Value& value);


Napi::Value toJsAttr(Napi::Env env, const AttrPair &attr);


/**
 * @brief 属性map类
 * @property objType python类的名称
 * @property thisObj js类的this指针
 */
class AttrMap : public std::map<const char*, Napi::Value> {
	private:
	const char* objType;
	Napi::Object thisObj;

	public:
	explicit AttrMap(Napi::Object thisObj, const char* type) : std::map<const char*, Napi::Value>(), objType(type), thisObj(thisObj) {}

	/**
		 * @brief 获取属性值
		 * @tparam T 将从getPyAttr获取的python属性值明确为T(cpp类型)类型.
		 * @tparam U 将cpp类型转换为js类型,并返回U类型.
		 * @param key 需要从该类中获取的属性名称.
		 * @details 由于该类是python-cpp-js的交互接口类,需要将从getPyAttr获取的python属性值
		 * 转换为cpp类型再转换成js类型,然后存入map,因此需要使用模板进行多次类型转换.get方法隐含了
		 * set操作,因此获取未设置的属性时会自动设置.
		 * @note 该重载实现使用通用转换,也许并不安全.
		 * @return 类型属性值
	 */
	Napi::Value get(const char* key) {
		if (find(key) == end()) {
			this->insert(std::make_pair(key, toJsAttr(thisObj.Env(), getPyAttr(objType, key, thisObj.Env()))));
		}
		return this->at(key);
	}

	template <typename T = std::any, Py2CppFn<T> CppTrans, Cpp2JsFn<T> JsTrans>
	/**
		 * @brief 获取属性值
		 * @tparam T 用于辅助检查的转换中间值类型(cpp类型)
		 * @tparam CppTrans 转换python属性值到cpp类型的函数模板.
		 * @tparam JsTrans 转换cpp类型到js类型的函数模板.
		 * @param key 需要从该类中获取的属性名称.
		 * @details 该重载实现使用模板参数化,可以指定转换函数模板,并检查返回类型是否与T一致.
		 * @note 该重载实现使用模板参数化,安全性取决于转换函数模板的正确性.
		 * @return 类型属性值
	 */
	auto get(const char* key) {
		if (find(key) == end()) {
			this->insert(std::make_pair(key, JsTrans(CppTrans(getPyAttr(objType, key, thisObj.Env())))));
		}
		return this->at(key).As<JsTrans>();
	}

	/**
		 * @brief 设置属性值
		 * @tparam T 值类型
		 * @param key 属性名称
		 * @param value 属性值
		 * @details 该方法设置属性值,并将属性值存入map,并将属性值设置到js类对象中.
	 */
	void set(const char* key, const Napi::Value& value) {
		this->insert(std::make_pair(key, value));
	}
};


#endif // BRIDGING__FUNCKIT_H
