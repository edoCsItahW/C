// Copyright (c) 2024. All rights reserved.
// This source code is licensed under the CC BY-NC-SA
// (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
// This software is protected by copyright law. Reproduction, distribution, or use for commercial
// purposes is prohibited without the author's permission. If you have any questions or require
// permission, please contact the author: 2207150234@st.sziit.edu.cn

/*****************************************************
 * @File name: bridging
 * @Author: edocsitahw
 * @Version: 1.1
 * @Date: 2024/08/10 下午1:59
 * @Commend:
 *******************************************************/

#ifndef BRIDGING_GLOBAL_H
#define BRIDGING_GLOBAL_H
#pragma once

#include <pybind11/pybind11.h>
#include <pybind11/embed.h>
#include <map>
#include <iostream>
#include <source_location>
#include <functional>
#include <napi.h>


namespace py = pybind11;


extern py::scoped_interpreter guard;


/** @brief python对象attr方法的返回类型,即python对象的属性类型 */
using PyAttr = py::detail::accessor<py::detail::accessor_policies::str_attr>;


/** 一个用于缓存python类的map(由于从模块导出同样返回PyAttr类型,所以不要误认为缓存的是类的属性)
	 *
	 * @property builtins 存贮导入的python内置模块,在构造函数中初始化.
	 * @brief 用于存储python类的map
	 * @note 该map仅提供get方法,set方法已隐含于get方法中.
	 * */
class InsMap : public std::map<const char*, PyAttr> {
	private:
	py::module builtins;

	public:
	~InsMap() = default;
	InsMap() : std::map<const char*, PyAttr>() {
		builtins = py::module::import("builtins");
	}

	/** 在map中获取属性值,如果属性不存在,则导入该属性并返回
		 * @brief 获取属性值
		 * @param key 属性名
		 * @return 属性值
	 */
	PyAttr get(const char *key, const std::source_location& loc = std::source_location::current()) {
		if (find(key) == end())
			this->insert(std::make_pair(key, builtins.attr(key)));
		return this->at(key);
	}
};


/**
 * @brief 缓存python类的InsMap的实例
 * @note 获取类时请使用该实例,而非重新从builtins中导入.
 */
extern InsMap* INS_CACHE;


#endif // BRIDGING_GLOBAL_H
