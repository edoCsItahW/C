// Copyright (c) 2024. All rights reserved.
// This source code is licensed under the CC BY-NC-SA
// (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
// This software is protected by copyright law. Reproduction, distribution, or use for commercial
// purposes is prohibited without the author's permission. If you have any questions or require
// permission, please contact the author: 2207150234@st.sziit.edu.cn

/*****************************************************
 * @File name: bridging
 * @Author: edocsitahw
 * @Version: 1.1
 * @Date: 2024/08/18 上午10:30
 * @Commend:
 *******************************************************/
#include "_funcKit.h"

AttrPair getPyAttr(const char* type, const char *key) {
	PyAttr obj = INS_CACHE->get(type);
	return AttrPair{obj.attr(key), py::type::of(obj.attr(key)).attr("__name__").cast<std::string>()};
}

AttrPair getPyAttr(const char* type, const char *key, Napi::Env env) {
	try {
		return getPyAttr(type, key);
	}
	catch (const std::exception& e) {
		Napi::Error::New(env, e.what()).ThrowAsJavaScriptException();
		return AttrPair{ py::none(), "None" };
	}
}

py::object toPyAttr(const Napi::Value& value) {
	if (value.IsNumber())
		return py::cast(value.ToNumber().Int32Value());

	else if (value.IsBoolean())
		return py::cast(value.ToBoolean());

	else if (value.IsString())
		return py::cast(value.ToString().Utf8Value());

	else if (value.IsArray()) {
		auto arr = value.As<Napi::Array>();
		py::list list;

		for (auto i = 0; i < arr.Length(); i++)
			list.append(toPyAttr(arr.Get(i)));

		return list;
	}

	else if (value.IsObject()) {
		auto obj = value.As<Napi::Object>();
		py::dict dict;

		for (auto it = obj.GetPropertyNames().begin(); it!= obj.GetPropertyNames().end(); ++it)
			dict[it.operator*().first.ToString().Utf8Value().c_str()] = toPyAttr(obj.Get(it.operator*().first));

		return dict;
	}

	else if (value.IsFunction()) {
		Napi::TypeError::New(value.Env(), "Unimplemented function type").ThrowAsJavaScriptException();
		return py::none();
		//		return py::cast([]() {})
	}

	else if (value.IsNull() || value.IsUndefined())
		return py::none();

	else {
		Napi::TypeError::New(value.Env(), "Unsupported type: " + value.ToString().Utf8Value()).ThrowAsJavaScriptException();
		return py::none();
	}
}

Napi::Value toJsAttr(Napi::Env env, const AttrPair &attr) {
	if (attr.second == "int")
		return Napi::Number::From(env, attr.first.cast<int>());

	else if (attr.second == "float")
		return Napi::Number::From(env, attr.first.cast<float>());

	else if (attr.second == "bool")
		return Napi::Boolean::From(env, attr.first.cast<bool>());

	else if (attr.second == "str")
		return Napi::String::New(env, attr.first.cast<std::string>());

	else if (attr.second == "list") {
		auto list = attr.first.cast<py::list>();
		auto arr = Napi::Array::New(env, list.size());

		for (auto& item : list)
			arr.Set(arr.Length() - 1, toJsAttr(env, AttrPair{item.cast<py::object>(),
															 py::type::of(item).attr("__name__").cast<std::string>()}));

		return arr;
	}

	else if (attr.second == "dict") {
		auto dict = attr.first.cast<py::dict>();
		auto obj = Napi::Object::New(env);

		for (auto& item : dict)
			obj.Set(item.first.cast<std::string>(),
					toJsAttr(env, AttrPair{item.second.cast<py::object>(),
										   py::type::of(item.second).attr("__name__").cast<std::string>()}));

		return obj;
	}

	else if (attr.second == "function"
			 || attr.second == "builtin_function_or_method"
			 || attr.second == "wrapper_descriptor"
	)
		return Napi::Function::New(env, [attr](const Napi::CallbackInfo& info) {
			std::vector<py::object> args;

			for (auto i = 0; i < info.Length(); i++) args.push_back(toPyAttr(info[i]));

			auto tpArgs = py::cast(args);

			auto func = attr.first.cast<py::function>();

			std::cout << "func: " << func.attr("__doc__").cast<std::string>() << std::endl;
			auto result = func();

			std::cout << "result: " << result.cast<std::string>() << std::endl;
			return toJsAttr(info.Env(), AttrPair{result, py::type::of(result).attr("__name__").cast<std::string>()});

		}, attr.first.attr("__name__").cast<std::string>().c_str());

	else if (attr.second == "None")
		return Napi::Value::From(env, nullptr);

	else {
		Napi::TypeError::New(env, "Unsupported type: " + attr.second).ThrowAsJavaScriptException();
		return env.Undefined();
	}
}
