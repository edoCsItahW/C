// Copyright (c) 2024. All rights reserved.
// This source code is licensed under the CC BY-NC-SA
// (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
// This software is protected by copyright law. Reproduction, distribution, or use for commercial
// purposes is prohibited without the author's permission. If you have any questions or require
// permission, please contact the author: 2207150234@st.sziit.edu.cn

/*****************************************************
 * @File name: bridging
 * @Author: edocsitahw
 * @Version: 1.1
 * @Date: 2024/08/10 下午1:57
 * @Commend:
 *******************************************************/

#ifndef BRIDGING_PYOBJECT_H
#define BRIDGING_PYOBJECT_H
#pragma once

#include "funcKit.h"

class ObjectAdapter : public Napi::ObjectWrap<ObjectAdapter> {
	protected:
	AttrMap attrs;

	public:
	explicit ObjectAdapter(const Napi::CallbackInfo &info);  // [外部调用]python的Object类不允许传入参数,如非空应抛出异常.
	static Napi::Object Init(Napi::Env env, Napi::Object exports);

	template<typename T, isChildOf<Napi::Value> U = Napi::Value>
	Napi::Value get(const Napi::CallbackInfo& info);

	template<isChildOf<Napi::Value> T = Napi::Value>
	void set(const Napi::CallbackInfo& info);
};

#endif // BRIDGING_PYOBJECT_H
