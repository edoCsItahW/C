// Copyright (c) 2024. All rights reserved.
// This source code is licensed under the CC BY-NC-SA
// (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
// This software is protected by copyright law. Reproduction, distribution, or use for commercial
// purposes is prohibited without the author's permission. If you have any questions or require
// permission, please contact the author: 2207150234@st.sziit.edu.cn

/*****************************************************
 * @File name: bridging
 * @Author: edocsitahw
 * @Version: 1.1
 * @Date: 2024/08/10 下午1:58
 * @Commend:
 *******************************************************/

#ifndef BRIDGING_FUNCKIT_H
#define BRIDGING_FUNCKIT_H
#pragma once

#include <any>
#include <napi.h>
#include "global.h"


template<class T, class U = py::object>
/**
	 * @tparam T 子类模板参数
	 * @tparam U 父类模板参数
	 * @brief 检测T是否是U的子类
 */
concept isChildOf = std::is_base_of<U, T>::value;


template<typename F, typename T>
/**
	 * @brief 转换python对象为cpp对象的函数模板
	 * @tparam F 转换函数类型,必须满足Py2CppFn concept.
	 * @tparam T 一个辅助检查类型,用于检查转换函数的返回类型是否与T一致.
 */
concept Py2CppFn = requires(F fn, py::object obj) { { fn(obj) } -> std::same_as<T>; };


template<typename F, typename T>
/**
	 * @brief 转换cpp对象为js对象的函数模板
	 * @tparam F 转换函数类型,必须满足Cpp2JsFn concept.
	 * @tparam T 一个辅助检查类型,用于检查转换函数作用于该类型后的返回类型是否与node::Value一致.
 */
concept Cpp2JsFn = requires(F fn, T cpp) { { fn(cpp) } -> std::same_as<Napi::Value>; };


/**
 * @brief 获取python属性
 * @tparam T 确定该返回属性的类型(父类必须为py::object)
 * @param type python类的名称,该名称将作为键在python的builtins中查找并导入对应的类.
 * @param key 需要从该类中获取的属性名称.
 * @return 类型属性值
 */
template<isChildOf<py::object> T = py::object>
py::object getPyAttr(const char* type, const char *key) {
	PyAttr obj = INS_CACHE->get(type);
	std::cout << py::type::of(obj.attr(key)).attr("__name__").cast<std::string>() << std::endl;
	return obj.attr(key).cast<T>();
}


template<isChildOf<py::object> T = py::object>
py::object getPyAttr(const char* type, const char *key, Napi::Env env) {
	try {
		return getPyAttr<T>(type, key);
	}
	catch (const std::exception& e) {
		Napi::Error::New(env, e.what()).ThrowAsJavaScriptException();
		return py::none();
	}
}


/**
 * @brief 属性map类
 * @property objType python类的名称
 * @property thisObj js类的this指针
 */
class AttrMap : public std::map<const char*, Napi::Value> {
	private:
	const char* objType;
	Napi::Object thisObj;

	public:
	explicit AttrMap(Napi::Object thisObj, const char* type) : std::map<const char*, Napi::Value>(), objType(type), thisObj(thisObj) {
	}

	template<typename T, isChildOf<Napi::Value> U = Napi::Value>
	/**
		 * @brief 获取属性值
		 * @tparam T 将从getPyAttr获取的python属性值明确为T(cpp类型)类型.
		 * @tparam U 将cpp类型转换为js类型,并返回U类型.
		 * @param key 需要从该类中获取的属性名称.
		 * @details 由于该类是python-cpp-js的交互接口类,需要将从getPyAttr获取的python属性值
		 * 转换为cpp类型再转换成js类型,然后存入map,因此需要使用模板进行多次类型转换.get方法隐含了
		 * set操作,因此获取未设置的属性时会自动设置.
		 * @note 该重载实现使用通用转换,也许并不安全.
		 * @return 类型属性值
	 */
	U get(const char* key) {
		if (find(key) == end()) {
			this->insert(std::make_pair(key, Napi::Value::From(thisObj.Env(), getPyAttr(objType, key, thisObj.Env()).cast<T>()).template As<U>()));
		}
		return this->at(key).As<U>();
	}

	template <typename T = std::any, Py2CppFn<T> CppTrans, Cpp2JsFn<T> JsTrans>
	/**
		 * @brief 获取属性值
		 * @tparam T 用于辅助检查的转换中间值类型(cpp类型)
		 * @tparam CppTrans 转换python属性值到cpp类型的函数模板.
		 * @tparam JsTrans 转换cpp类型到js类型的函数模板.
		 * @param key 需要从该类中获取的属性名称.
		 * @details 该重载实现使用模板参数化,可以指定转换函数模板,并检查返回类型是否与T一致.
		 * @note 该重载实现使用模板参数化,安全性取决于转换函数模板的正确性.
		 * @return 类型属性值
	 */
	auto get(const char* key) {
		if (find(key) == end()) {
			this->insert(std::make_pair(key, JsTrans(CppTrans(getPyAttr(objType, key)))));
		}
		return this->at(key).As<JsTrans>();
	}

	template<isChildOf<Napi::Value> T = Napi::Value>
	/**
		 * @brief 设置属性值
		 * @tparam T 值类型
		 * @param key 属性名称
		 * @param value 属性值
		 * @details 该方法设置属性值,并将属性值存入map,并将属性值设置到js类对象中.
	 */
	void set(const char* key, const T& value) {
		this->insert(std::make_pair(key, value));
	}
};


#endif // BRIDGING_FUNCKIT_H
