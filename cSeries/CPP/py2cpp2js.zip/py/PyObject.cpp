// Copyright (c) 2024. All rights reserved.
// This source code is licensed under the CC BY-NC-SA
// (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
// This software is protected by copyright law. Reproduction, distribution, or use for commercial
// purposes is prohibited without the author's permission. If you have any questions or require
// permission, please contact the author: 2207150234@st.sziit.edu.cn

/*****************************************************
 * @File name: bridging
 * @Author: edocsitahw
 * @Version: 1.1
 * @Date: 2024/08/10 下午2:05
 * @Commend:
 *******************************************************/


#include "PyObject.h"


/**
 * [外部调用]python的Object类不允许传入参数,如非空应抛出异常.
 *
 * @param info 调用信息
 * @return ObjectAdapter
 */
ObjectAdapter::ObjectAdapter(const Napi::CallbackInfo& info)
	: ObjectWrap(info), attrs(info.This().As<Napi::Object>(), "object") {
	if (info.Length())
		Napi::TypeError::New(info.Env(), "object() takes no arguments").ThrowAsJavaScriptException();
}


template<typename T, isChildOf<Napi::Value> U>
Napi::Value ObjectAdapter::get(const Napi::CallbackInfo& info) {
	if (info.Length() != 1)
		Napi::TypeError::New(info.Env(), "get() takes exactly one argument, and you have " + std::to_string(info.Length()) + " arguments").ThrowAsJavaScriptException();

	return attrs.get<T, U>(info[0].As<Napi::String>().Utf8Value().data());
}


template<isChildOf<Napi::Value> T>
void ObjectAdapter::set(const Napi::CallbackInfo& info) {
	if (info.Length() != 2)
		Napi::TypeError::New(info.Env(), "set() takes exactly two arguments " + std::to_string(info.Length()) + " arguments").ThrowAsJavaScriptException();

	attrs.set<T>(info[0].As<Napi::String>().Utf8Value().data(), info[1].As<T>());
}


Napi::Object ObjectAdapter::Init(Napi::Env env, Napi::Object exports) {
	Napi::Function func = DefineClass(
		env,
		"PyObject",
		{
			InstanceMethod("get", &ObjectAdapter::get<std::string, Napi::Value>),
			InstanceMethod("set", &ObjectAdapter::set<Napi::Value>)
		}
	);

	exports.Set("PyObject", func);
	return exports;
}
