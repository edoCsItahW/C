# HandleScope (句柄作用域)

The HandleScope class is used to manage the lifetime of object handles
which are created through the use of node-addon-api. These handles
keep an object alive in the heap in order to ensure that the objects
are not collected while native code is using them.
A handle may be created when any new node-addon-api Value or one
of its subclasses is created or returned. For more details refer to
the section titled [Object lifetime management](object_lifetime_management.md).

HandleScope类用于管理通过使用node-addon-api创建的对象句柄的生命周期。这些句柄
使对象在堆中保持活动状态，以确保在本机代码使用对象时不会收集对象。当创建或返回任何新
节点插件api值或其子类时，可以创建句柄。有关更多详细信息，请参阅标题为
[对象生存期管理](Object_lifetime_management.md)的部分。

## Methods

### Constructor

在堆栈上创建新的句柄作用域。

```cpp
Napi::HandleScope::HandleScope(Napi::Env env);
```

- `[in] env`: The environment in which to construct the `Napi::HandleScope` object.

Returns a new `Napi::HandleScope`

### Constructor

Creates a new handle scope on the stack.

```cpp
Napi::HandleScope::HandleScope(Napi::Env env, Napi::HandleScope scope);
```

- `[in] env`: `Napi::Env` in which the scope passed in was created.
- `[in] scope`: pre-existing `Napi::HandleScope`.

Returns a new `Napi::HandleScope` instance which wraps the `napi_handle_scope`
handle passed in.  This can be used to mix usage of the C Node-API
and node-addon-api.

```cpp
operator Napi::HandleScope::napi_handle_scope() const
```

Returns the Node-API `napi_handle_scope` wrapped by the `Napi::EscapableHandleScope` object.
This can be used to mix usage of the C Node-API and node-addon-api by allowing
the class to be used be converted to a `napi_handle_scope`.

### Destructor
```cpp
Napi::HandleScope::~HandleScope();
```

Deletes the `Napi::HandleScope` instance and allows any objects/handles created
in the scope to be collected by the garbage collector.  There is no
guarantee as to when the garbage collector will do this.

### Env

```cpp
Napi::Env Napi::HandleScope::Env() const;
```

Returns the `Napi::Env` associated with the `Napi::HandleScope`.

## Example

```cpp
for (int i = 0; i < LOOP_MAX; i++) {
  Napi::HandleScope scope(info.Env());
  std::string name = std::string("inner-scope") + std::to_string(i);
  Napi::Value newValue = Napi::String::New(info.Env(), name.c_str());
  // do something with newValue
};
```

For more details refer to the section titled [Object lifetime
management](object_lifetime_management.md).
