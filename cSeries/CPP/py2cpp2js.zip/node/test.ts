/*
 * Copyright (c) 2024. All rights reserved.
 * This source code is licensed under the CC BY-NC-SA
 * (Creative Commons Attribution-NonCommercial-NoDerivatives) License, By Xiao Songtao.
 * This software is protected by copyright law. Reproduction, distribution, or use for commercial
 * purposes is prohibited without the author's permission. If you have any questions or require
 * permission, please contact the author: 2207150234@st.sziit.edu.cn
 */
// @ts-ignore
import bridging from '../build/Release/bridging'


// @ts-ignore
// const obj = new Proxy(new bridging.PyObject(), {
//     get: (target: bridging.PyObject, p: string) => { return target.get(p); },
//     set: (target: bridging.PyObject, p: string, value: any) => { return target.set(p, value); }
// })


try {
    const obj = new bridging.PyObject()
    console.log(obj.get('__doc__'))
}
catch (e) {
    console.error(e)
}
